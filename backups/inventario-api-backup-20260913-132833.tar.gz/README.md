# Respaldo lógico Inventario CUP · STOCK

- Fecha UTC: 2026-09-13T13:28:56.288134+00:00
- Origen: https://inventario.lpaezsis.cl
- Productos: 20
- Movimientos: 36 (entradas 21, salidas 15)
- Stock total (unidades): 73.0
- Valor inventario (stock × CUP): 8265086.67

## Archivos
- `backup-full.json` — dump completo (products + movements + dashboard)
- `products.json` / `movements.json` / `dashboard.json` — APIs crudas
- `articulos.csv` / `movimientos.csv` — Excel (separador `;`)
- `summary.json` — conteos y totales

## Nota
Esto es un respaldo **lógico vía API**. El respaldo físico completo de SQLite es descargar `data/prod.db` desde cPanel (Application root).
